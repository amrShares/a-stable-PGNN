from math import sqrt
import numpy as np
import torch

class BuriedChannelWaveguide:

  def __init__(self, n_core, n_substrate, lambd, lengths_x, lengths_y, study, field_type):
    self.n_core = n_core
    self.n_substrate = n_substrate
    self.n_cladding = n_substrate

    self.lambd = lambd
    self.lengths_x = lengths_x
    self.lengths_y = lengths_y
    self.study = study
    self.field_type = field_type

    self.total_length_x = sum(lengths_x)
    self.total_length_y = sum(lengths_y)
    self.k_0 = 2 * np.pi / lambd

  def refractive_index(self, xy: torch.Tensor, format='numpy'):
    if format == 'numpy':
      out = np.ones((len(xy), 1))
    else:
      out = torch.ones(len(xy), 1, dtype=xy.dtype, device=xy.device)

    core_mask = (abs(xy[:, 0]) <= self.lengths_x[1]/2) & (abs(xy[:, 1]) <= self.lengths_y[1]/2)
    out[core_mask] = self.n_core
    out[~core_mask] = self.n_substrate

    return out

  def regions(self, xy: torch.Tensor, format='numpy'):
    if format == 'numpy':
      out = np.ones((len(xy), 1))
    else:
      out = torch.ones(len(xy), 1, dtype=xy.dtype, device=xy.device)

    core_mask = (abs(xy[:, 0]) <= self.lengths_x[1]/2) & (abs(xy[:, 1]) <= self.lengths_y[1]/2)
    out[core_mask] = 0
    out[~core_mask] = 1

    return out

  def get_discontinuities(self, xy, dx, dy):

    mask_left = (abs(xy[:, 0] + self.lengths_x[1]/2) < dx) & (xy[:, 0] >= -self.lengths_x[1]/2)  & (abs(xy[:, 1]) < self.lengths_y[1]/2)
    left_interface = xy[mask_left]

    mask_right = (abs(xy[:, 0] - self.lengths_x[1]/2) < dx) & (xy[:, 0] <= self.lengths_x[1]/2) & (abs(xy[:, 1]) < self.lengths_y[1]/2)
    right_interface = xy[mask_right]

    mask_bottom = (abs(xy[:, 1] + self.lengths_y[1]/2) < dy) & (xy[:, 1] >= -self.lengths_y[1]/2) & (abs(xy[:, 0]) < self.lengths_x[1]/2)
    bottom_interface = xy[mask_bottom]

    mask_top = (abs(xy[:, 1] - self.lengths_y[1]/2) < dy) & (xy[:, 1] <= self.lengths_y[1]/2) & (abs(xy[:, 0]) < self.lengths_x[1]/2)
    top_interface = xy[mask_top]

    return left_interface, right_interface, bottom_interface, top_interface

  def get_boundaries(self, dx, dy, dtype,  memory_type):
    X = torch.arange(0, self.total_length_x/2, dx, dtype=dtype, device=memory_type).reshape(-1, 1)
    X = torch.cat((torch.flip(-X, dims=(0,))[:-1], X))

    Y = torch.arange(0, self.total_length_y/2, dy, dtype=dtype, device=memory_type).reshape(-1, 1)
    Y = torch.cat((torch.flip(-Y, dims=(0,))[:-1], Y))

    bd_1 = torch.cat((torch.empty_like(Y).fill_(X[0, 0]), Y), dim=1)
    y_bd1 = torch.zeros_like(Y)

    bd_2 = torch.cat((torch.empty_like(Y).fill_(X[-1, 0]), Y), dim=1)
    y_bd2 = torch.zeros_like(Y)

    bd_3 = torch.cat((X, torch.empty_like(X).fill_(Y[0, 0])), dim=1)
    y_bd3 = torch.zeros_like(X)

    bd_4 = torch.cat((X, torch.empty_like(X).fill_(Y[-1, 0])), dim=1)
    y_bd4 = torch.zeros_like(X)

    bd = torch.cat((bd_1, bd_2, bd_3, bd_4), dim=0)
    u_bd = torch.cat((y_bd1, y_bd2, y_bd3, y_bd4), dim=0)
    return bd, u_bd

  @property
  def central_region(self):
    return self.lengths_x[1]/2, self.lengths_y[1]/2
