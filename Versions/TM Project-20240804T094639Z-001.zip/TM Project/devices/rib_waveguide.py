from math import sqrt
import torch
import numpy as np

class RibWaveguide:

  def __init__(self, n_substrate, n_core, n_cladding, lambd, lengths_x, lengths_y, study):
    self.n_substrate = n_substrate
    self.n_core = n_core
    self.n_cladding = n_cladding

    self.lambd = lambd
    self.lengths_x = lengths_x # substrate core substrate
    self.lengths_y = lengths_y # substrate rib core cladding
    self.study = study

    self.total_length_x = sum(lengths_x)
    self.total_length_y = sum(lengths_y)
    
    self.upward_length = lengths_y[2] + lengths_y[3]
    self.downward_length = lengths_y[0] + lengths_y[1]
    
    self.k_0 = 2 * np.pi / lambd
    
    
    self.total_area = self.total_length_x * self.total_length_y
    self.effective_area = self.lengths_x[1] * self.lengths_y[1]

  def refractive_index(self, xy: torch.Tensor, format='numpy'):
    if format == 'numpy':
      out = np.ones((len(xy), 1))
    else:
      out = torch.ones(len(xy), 1, dtype=xy.dtype, device=xy.device)
    
    lower_sub_mask = xy[:, 1]<0
    upper_clad_mask = xy[:, 1]>0
    core_mask = (abs(xy[:, 0]) <= self.lengths_x[1]/2) & (xy[:, 1]>=0) & (xy[:, 1]<=self.lengths_y[2])
    rib_mask = (xy[:, 1]<=0) & (xy[:, 1]>=-self.lengths_y[1])

    out[lower_sub_mask] = self.n_substrate
    out[upper_clad_mask] = self.n_cladding
    out[core_mask] = self.n_core
    out[rib_mask] = self.n_core

    return out

  def regions(self, xy: torch.Tensor, format='numpy'):
    if format == 'numpy':
      out = np.ones((len(xy), 1))
    else:
      out = torch.ones(len(xy), 1, dtype=xy.dtype, device=xy.device)
    
    lower_sub_mask = xy[:, 1]<0
    upper_clad_mask = xy[:, 1]>=0
    core_mask = (abs(xy[:, 0]) <= self.lengths_x[1]/2) & (xy[:, 1]>0) & (xy[:, 1]<=self.lengths_y[2])
    rib_mask = (xy[:, 1]<=0) & (xy[:, 1]>=-self.lengths_y[1])
    
    out[lower_sub_mask] = -1
    out[upper_clad_mask] = 1
    out[core_mask] = 0
    out[rib_mask] = 0

    return out

  def get_discontinuities(self, xy, dx, dy):
    end_val_x = ((self.total_length_x/2)//dx)*dx
    len_rib = ((self.lengths_y[1])//dy)*dy
    end_val_yb = ((self.downward_length)//dy)*dy
        
    mask_left = (abs(xy[:, 0] + self.lengths_x[1]/2) < dx) & (xy[:, 0] + self.lengths_x[1]/2 >= 0 )  & (xy[:, 1]>0) & (xy[:, 1]<=self.lengths_y[2])
    mask_right = (abs(xy[:, 0] - self.lengths_x[1]/2) < dx) & (xy[:, 0] - self.lengths_x[1]/2 <= 0 ) & (xy[:, 1]>0) & (xy[:, 1]<=self.lengths_y[2])
    
    mask_bottom = (abs(xy[:, 1] + len_rib) < dy/2) & (abs(xy[:, 0]) < (end_val_x - dx/2))
    mask_center = (abs(xy[:, 1]) < dy) & (xy[:, 1] >= 0) & (abs(xy[:, 0]) > self.lengths_x[1]/2) & (abs(xy[:, 0]) < (end_val_x - dx/2))
    mask_top = (abs(xy[:, 1] - self.lengths_y[2]) < dy) & (xy[:, 1] - self.lengths_y[2] <= 0) & (abs(xy[:, 0]) < self.lengths_x[1]/2)

    mask_top_ = mask_top & (~mask_right) & (~mask_left)
#     mask_center_ = mask_center & (~mask_right) & (~mask_left)
#     mask_bottom_ = mask_bottom

#     mask_left_ = mask_left & (~mask_center) & (~mask_top)
#     mask_right_ = mask_right & (~mask_center) & (~mask_top)

    left_interface = xy[mask_left]
    right_interface = xy[mask_right]
    bottom_interface = xy[mask_bottom]
    center_interface = xy[mask_center]
    top_interface = xy[mask_top_]

    return torch.cat((bottom_interface, center_interface, top_interface)), torch.cat((left_interface, right_interface))

  def get_boundaries(self, xy, dx, dy, dtype,  memory_type):
    end_val_x = ((self.total_length_x/2)//dx)*dx
    end_val_yu = ((self.upward_length)//dy)*dy
    end_val_yb = ((self.downward_length)//dy)*dy
    
    mask_left = xy[:, 0] <= -end_val_x + dx/2
    mask_right = xy[:, 0] >= end_val_x - dx/2
    
    mask_bottom = xy[:, 1] <= -end_val_yb + dy/2
    mask_bottom = mask_bottom & (~mask_right) & (~mask_left)

    mask_top = xy[:, 1] >= end_val_yu - dy/2
    mask_top = mask_top & (~mask_right) & (~mask_left)

    left_bd = xy[mask_left]
    right_bd = xy[mask_right]
    bottom_bd = xy[mask_bottom]
    top_bd = xy[mask_top]

    bd = torch.cat((left_bd, right_bd, bottom_bd, top_bd), dim=0)
    u_bd = torch.zeros_like(bd[:, [0]])
    return bd, u_bd

  @property
  def central_region(self):
    return self.lengths_x[1]/2, self.lengths_y[1]/2

  @property
  def simulation_lengths_x(self):
    return self.total_length_x/2, self.total_length_x/2

  @property
  def simulation_lengths_y(self):
    return self.upward_length, self.downward_length
