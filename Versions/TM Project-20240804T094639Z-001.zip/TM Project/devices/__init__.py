from .slab_waveguide import SlabWaveguide
from .slab_waveguide_FD import SlabWaveguideWithFD
from .slab_waveguide_nn import SlabWaveguideWithPINNs
from .waveguide import WaveGuide
from .waveguide_nn import WaveGuideWithPINNs

from .buried_channel_waveguide import BuriedChannelWaveguide
from .buried_channel_waveguide_nn import BuriedChannelWaveguideWithPINNs

from .rib_waveguide import RibWaveguide
from .rib_waveguide_nn import RibWaveguideWithPINNs