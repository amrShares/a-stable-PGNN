from functools import partial

import torch
import torch.nn as nn
import numpy as np

class RBF(nn.Module):
    def __init__(self, in_features):
      super().__init__()
      self.divisor = nn.Parameter(torch.ones(1, in_features))
    def forward(self, x):
        return torch.exp(-(x/self.divisor)**2)

class DRBF(nn.Module):
    def __init__(self, in_features):
      super().__init__()
      self.divisor = nn.Parameter(torch.ones(1, in_features))
    def forward(self, x):
        x_scaled = x/self.divisor
        return - 2 * x_scaled * torch.exp(-x_scaled**2)

class Trig(nn.Module):
    def forward(self, x):
        return torch.cat((torch.cos(x), torch.sin(x)), dim=-1)

def vanilla_network(in_features, hidden_features, out_features, num_hidden_layers, nonlinearity='RBF'):
	
	if nonlinearity=='RBF':
		f = partial(RBF, hidden_features)
	elif nonlinearity=='DRBF':
		f = partial(DRBF, hidden_features)
	elif nonlinearity=='tanh':
		f = nn.Tanh
	layers = [nn.Linear(in_features, hidden_features), f()]
	for i in range(num_hidden_layers - 1):
		layers.extend([nn.Linear(hidden_features, hidden_features), f()])
	layers.append(nn.Linear(hidden_features, out_features))
	
	return nn.Sequential(*layers)

def discontinuity_capturing_network(in_features, hidden_features, out_features, num_hidden_layers, nonlinearity='RBF'):
	
	if nonlinearity=='RBF':
		f = partial(RBF, hidden_features)
	elif nonlinearity=='DRBF':
		f = partial(DRBF, hidden_features)
	elif nonlinearity=='tanh':
		f = nn.Tanh
	layers = [nn.Linear(in_features + 1, hidden_features), f()]
	for i in range(num_hidden_layers - 1):
		layers.extend([nn.Linear(hidden_features, hidden_features), f()])
	layers.append(nn.Linear(hidden_features, out_features))
	
	return nn.Sequential(*layers)
	

class FieldNet(nn.Sequential):
    def __init__(self, in_features, hidden_features, out_features, nonlinearity='RBF', discontinuities=[]):
        super().__init__()
        self.discontinuities = discontinuities[:]
        self.num_modes = out_features
        self.subnets = nn.ModuleList()

        if nonlinearity=='RBF':
          f = partial(RBF, hidden_features)
        elif nonlinearity=='DRBF':
          f = partial(DRBF, hidden_features)
        elif nonlinearity=='tanh':
          f = nn.Tanh

        for i in range(len(discontinuities) + 1):
            subnet = nn.Sequential(
                nn.Linear(in_features=in_features, out_features=hidden_features),
                f(),
                nn.Linear(in_features=hidden_features, out_features=out_features)
            )
            self.subnets.append(subnet)

        self.discontinuities.append(np.finfo(np.float32).max)
        self.discontinuities.insert(0, np.finfo(np.float32).min)

    def forward(self, x):
        outputs = [torch.zeros(len(x), self.num_modes, device=x.device, dtype=x.dtype)]
        for i in range(len(self.discontinuities) - 1):
            outputs[0] += self.subnets[i](x) * ((self.discontinuities[i] < x) & (x <= self.discontinuities[i + 1]))
        return outputs[0]

