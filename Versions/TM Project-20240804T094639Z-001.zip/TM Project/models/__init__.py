from .models import vanilla_network
from .models import discontinuity_capturing_network
from .models import FieldNet