import torch
import numpy as np
import matplotlib.pyplot as plt

def compare_against_analytic(device, x, u):
    mode_errors = []
    num_samples, num_modes = len(u), len(u.T)

    evaluation_points, eigen_modes_analytic, eigen_funcs_analytic = device.evaluate_analytical(x, num_modes)
    
    if device.study == 'TM' and device.field_type=='E':
      print('adjusting for Ex in a TM study')
      eigen_funcs_analytic = eigen_funcs_analytic / device.refractive_index(evaluation_points.reshape(-1), format='numpy')**2
    
    eigen_funcs_analytic /= np.linalg.norm(eigen_funcs_analytic, axis=-1, keepdims=True)
    eigen_funcs_analytic = eigen_funcs_analytic.reshape(num_modes, num_samples)

    print('mode errors')
    for i in range(num_modes):
        prediction_normed = u[:, i].detach().cpu() / torch.linalg.norm(u[:, i].cpu())
        assert prediction_normed.shape == eigen_funcs_analytic[i].shape 
        print('*' * 10)
        print('NN vs analytic')
        err_1 = (torch.mean((prediction_normed - eigen_funcs_analytic[i]) ** 2) / np.mean(
            eigen_funcs_analytic[i] ** 2)) ** 0.5 * 100
        err_2 = (torch.mean((prediction_normed + eigen_funcs_analytic[i]) ** 2) / np.mean(
            eigen_funcs_analytic[i] ** 2)) ** 0.5 * 100
        print(f'relative error for mode {i} is {round(min(abs(err_1.item()), abs(err_2.item())), 5)}%')
        print('*' * 10)
        mode_errors.append(min(abs(err_1.item()), abs(err_2.item())))
    plt.plot(prediction_normed)
    plt.plot(eigen_funcs_analytic[i])
    plt.show()
    return  mode_errors