import torch
import numpy as np
import torch.nn as nn
import tqdm
import utils
import matplotlib.pyplot as plt
import devices

class Trainer2D:
    def __init__(self, dtype, device, memory_type,sampler, optimzer, scheduler, dx=None, dy=None, num_samples=None, n_lower=None, n_upper=None):
      self.sampler = sampler
      self.optimizer = optimzer
      self.scheduler = scheduler
      self.device = device
      self.dtype = dtype
      self.n_lower = n_lower
      self.n_upper = n_upper

      if self.n_lower is None:
        self.n_lower = max(self.device.n_cladding, self.device.n_substrate)
      if self.n_upper is None:
        self.n_upper = self.device.n_core

      self.dx = dx
      self.dy = dy
      self.num_samples = num_samples
      self.memory_type = memory_type

    @staticmethod
    def adaptive_sampling(sampled_values, residuals, num, device=torch.device('cpu')):
        res_as_prob = torch.exp(residuals)
        res_as_prob = res_as_prob/torch.sum(res_as_prob)
        sorted_values, sorting_indices = torch.sort(sampled_values)
        cumulative_distribution = torch.cumsum(res_as_prob[sorting_indices], dim=0)
        uniform_samples = torch.rand(num, device=device)
        a = cumulative_distribution.reshape(1, -1) - uniform_samples.reshape(-1, 1)
        mask1 = (a>0) * np.finfo(np.float32).eps
        mask2 = (a<0) * -np.finfo(np.float32).max
        a *= (mask1 + mask2)
        new_sampled_values = sorted_values[torch.topk(a, k=1, dim=-1, largest=False).indices]
        new_sampled_values += torch.randn_like(new_sampled_values, device=device) * 0.01
        return new_sampled_values

    def bd_loss(self, u_bd, u_pred_bd):
        return torch.mean(torch.abs(u_bd - u_pred_bd))

    def continuity_loss(self, interfaces, num_modes):
        horizontal_interface, vertical_interface = interfaces[0], interfaces[1]
        
        horizontal_interface_bias = torch.zeros_like(horizontal_interface)
        horizontal_interface_bias[:, 1] = 2*self.dy
        
        vertical_interface_bias= torch.zeros_like(vertical_interface)
        vertical_interface_bias[:, 0] = 2*self.dx
    
        horizontal_RI_squared_before = torch.square(self.device.refractive_index(horizontal_interface-horizontal_interface_bias, format='torch')).detach()
        horizontal_RI_squared_after = torch.square(self.device.refractive_index(horizontal_interface+horizontal_interface_bias, format='torch')).detach()
        vertical_RI_squared_before = torch.square(self.device.refractive_index(vertical_interface-vertical_interface_bias, format='torch')).detach()
        vertical_RI_squared_after = torch.square(self.device.refractive_index(vertical_interface+vertical_interface_bias, format='torch')).detach()
        
        if self.device.augmented_input: 
            horizontal_input_b = torch.cat((horizontal_interface, horizontal_RI_squared_before), dim=1)
            horizontal_input_a = torch.cat((horizontal_interface, horizontal_RI_squared_after), dim=1)

            vertical_input_b = torch.cat((vertical_interface, vertical_RI_squared_before), dim=1)
            vertical_input_a = torch.cat((vertical_interface, vertical_RI_squared_after), dim=1)

        else:
            horizontal_input_b = horizontal_interface-horizontal_interface_bias
            horizontal_input_a = horizontal_interface+horizontal_interface_bias

            vertical_input_b = vertical_interface-vertical_interface_bias
            vertical_input_a = vertical_interface+vertical_interface_bias

        loss = torch.zeros(1, device=self.memory_type)

        horizontal_output_n_modes_b = self.device.underlying_model(horizontal_input_b)
        horizontal_output_n_modes_a = self.device.underlying_model(horizontal_input_a)

        vertical_output_n_modes_b = self.device.underlying_model(vertical_input_b)
        vertical_output_n_modes_a = self.device.underlying_model(vertical_input_a)
        
        for i in range(num_modes):
            horizontal_output_b = horizontal_output_n_modes_b[:, [i]]
            horizontal_output_a = horizontal_output_n_modes_a[:, [i]]
            
            vertical_output_b = vertical_output_n_modes_b[:, [i]]
            vertical_output_a = vertical_output_n_modes_a[:, [i]]
            
            grad_horizontal_out_b = torch.autograd.grad(horizontal_output_b.sum(), horizontal_interface, create_graph=True)[0]
            grad_horizontal_out_a = torch.autograd.grad(horizontal_output_a.sum(), horizontal_interface, create_graph=True)[0]

            grad_vertical_out_b = torch.autograd.grad(vertical_output_b.sum(), vertical_interface, create_graph=True)[0]
            grad_vertical_out_a = torch.autograd.grad(vertical_output_a.sum(), vertical_interface, create_graph=True)[0]

            loss_horizontal_grad = torch.mean(torch.abs((grad_horizontal_out_b) - (grad_horizontal_out_a)))
            loss_vertical_grad = torch.mean(torch.abs((grad_vertical_out_b) - (grad_vertical_out_a)))

            if self.device.study=='TM':
                loss_horizontal = torch.mean(torch.abs(horizontal_RI_squared_after*horizontal_output_a - horizontal_RI_squared_before*horizontal_output_b))
                loss_vertical = torch.mean(torch.abs(vertical_output_a - vertical_output_b))
            elif self.device.study=='TE':
                loss_horizontal = torch.mean(torch.abs(horizontal_output_a - horizontal_output_b))
                loss_vertical = torch.mean(torch.abs(vertical_RI_squared_after*vertical_output_a - vertical_RI_squared_before*vertical_output_b))
            else:
                loss_horizontal = torch.mean(torch.abs(horizontal_output_a - horizontal_output_b))
                loss_vertical = torch.mean(torch.abs(vertical_output_a - vertical_output_b))

            loss +=  loss_horizontal_grad + loss_vertical_grad + loss_horizontal + loss_vertical

        return loss

    # def continuity_loss(self, discontinuities, num_modes):
    #     loss = torch.zeros(1, 1, device=self.memory_type)
        
    #     refractive_indices_squared = torch.tensor([[self.device.n_substrate], [self.device.n_core], [self.device.n_cladding]], device=self.memory_type, dtype=self.dtype).reshape(-1, 1) ** 2
    #     if self.device.continuous_horizontal:
    #         continuities = [True, True, False, False]
    #     else:
    #         continuities = [False, False, True, True]

    #     for i in range(len(discontinuities)):
    #         for j in range(num_modes):
    #             if self.device.augmented_input:
    #                 refractive_index_tensor_i = torch.full_like(discontinuities[i][:, [0]], refractive_indices_squared[[i % 2]].item())
    #                 refractive_index_tensor_i_plus_1 = torch.full_like(discontinuities[i][:, [0]], refractive_indices_squared[[(i + 1) % 2]].item())
    #                 interface_input_b = torch.cat((discontinuities[i], refractive_index_tensor_i), dim=-1)
    #                 interface_input_a = torch.cat((discontinuities[i], refractive_index_tensor_i_plus_1), dim=-1)
    #             else:
    #                 interface_input_b = discontinuities[i] - self.dx
    #                 interface_input_a = discontinuities[i] + self.dx

    #             before_val = self.device.underlying_model(interface_input_b)[:, j]
    #             after_val = self.device.underlying_model(interface_input_a)[:, j]

    #             grad_before = torch.autograd.grad(before_val.sum(), discontinuities[i], create_graph=True)[0]
    #             grad_after = torch.autograd.grad(after_val.sum(), discontinuities[i], create_graph=True)[0]

    #             if self.device.augmented_input:
    #                 loss += torch.mean(torch.abs(grad_after - grad_before))
    #                 if continuities[i]:
    #                     loss += torch.mean(torch.abs(before_val - after_val))
    #                 else:
    #                     loss += torch.mean(torch.abs(refractive_indices_squared[i % 2] * before_val - refractive_indices_squared[(i + 1) % 2] * after_val))
    #             else:
    #                 if not continuities[i]:
    #                     loss += torch.mean(torch.abs(refractive_indices_squared[i % 2] * before_val - refractive_indices_squared[(i + 1) % 2] * after_val))

    #     return loss


    # def continuity_loss(self, discontinuities, num_modes):
    #     loss = [torch.zeros(1, 1, device=self.memory_type)]
        
    #     refractive_indices_squared = torch.tensor([[self.device.n_substrate], [self.device.n_core], [self.device.n_cladding]], device=self.memory_type, dtype=self.dtype).reshape(-1, 1) ** 2
    #     if self.device.continuous_horizontal:
    #       continuities = [True, True, False, False]
    #     else:
    #       continuities = [False, False, True, True]

    #     for i in range(len(discontinuities)):
    #         for j in range(num_modes):
    #             if self.device.augmented_input:
    #                 refractive_index_tensor_i = torch.full_like(discontinuities[i][:, [0]], refractive_indices_squared[[i%2]].item())
    #                 refractive_index_tensor_i_plus_1 = torch.full_like(discontinuities[i][:, [0]], refractive_indices_squared[[(i+1)%2]].item())
    #                 interface_input_b = torch.cat((discontinuities[i], refractive_index_tensor_i), dim=-1)
    #                 interface_input_a = torch.cat((discontinuities[i], refractive_index_tensor_i_plus_1), dim=-1)
    #             else:
    #                 interface_input_b = discontinuities[i]-self.dx
    #                 interface_input_a = discontinuities[i]+self.dx

    #             before_val = self.device.underlying_model(interface_input_b)[:, j]
    #             after_val = self.device.underlying_model(interface_input_a)[:, j]

    #             # grad_before = torch.autograd.grad(before_val.sum(), discontinuities[i], create_graph=True)[0]
    #             # grad_after = torch.autograd.grad(after_val.sum(), discontinuities[i], create_graph=True)[0]

    #             if self.device.augmented_input:
    #               # loss.append(torch.sum(torch.abs(grad_after - grad_before)))
    #               if continuities[i]:
    #                 loss.append(torch.sum(torch.abs(before_val - after_val)))
    #               else:
    #                 loss.append(torch.sum(torch.abs(refractive_indices_squared[i%2]*before_val - refractive_indices_squared[(i+1)%2]*after_val)))
    #             else:
    #               if not continuities[i]:
    #                 loss.append(torch.sum(torch.abs(refractive_indices_squared[i%2]*before_val - refractive_indices_squared[(i+1)%2]*after_val)))

    #     return sum(loss)

    def interior_loss(self, xy, u, num_modes):
        cosine_similarity_fn = nn.CosineSimilarity(dim=0, eps=1e-6)

        losses_1 = torch.zeros(1, device=xy.device)
        losses_2 = torch.zeros(1, device=xy.device)
        losses_3 = torch.zeros(1, device=xy.device)
        losses_4 = torch.zeros(1, device=xy.device)
        rayleigh_values = []

        n_squared = torch.square(self.device.refractive_index(xy, format='torch').detach())[:, 0]
        # guiding_mask = abs(n_squared - self.device.n_core**2)<0.001
        # weights = torch.ones_like(u[:, 0])
        # weights[guiding_mask] = 2

        for i in range(num_modes):
            du = torch.autograd.grad(u[:, i].sum(), xy, create_graph=True, retain_graph=True)[0]

            du_dx = du[:, 0]
            d2u_dx2 = torch.autograd.grad(du_dx.sum(), xy, create_graph=True)[0][:, 0]

            du_dy = du[:, 1]
            d2u_dy2 = torch.autograd.grad(du_dy.sum(), xy, create_graph=True)[0][:, 1]

            rayleigh = devices.RibWaveguideWithPINNs.get_rayleigh_quotient(d2u_dx2, d2u_dy2, n_squared, u[:, i])
            
            # rayleigh_diff = rayleigh - rayleigh_history[i][-1]
            # if len(rayleigh_values[i]) == 0:
            #   rayleigh_values[i].append(rayleigh.item())

    #         m=2
    #         b = (n_upper**2 - m**2)/(m*(n_lower**2 - n_upper**2))
    #         a = (n_upper**2)/(m+b)

            m= 3 # 3 good for scalar
            a = (self.n_upper**2 - self.n_lower**2)/(m-1)
            b = (m*self.n_lower**2 - self.n_upper**2)/(self.n_upper**2 - self.n_lower**2)

            losses_1 += torch.mean(torch.abs(d2u_dx2 + d2u_dy2 + (n_squared - rayleigh) * u[:, i]))
            losses_2 += torch.square(torch.sum(u[:, i] ** 2) * (self.device.n_core**2 - self.device.n_substrate**2) * 10 /  len(u) - 1)
            losses_3 += torch.maximum(self.n_lower ** 2 - rayleigh, torch.zeros_like(rayleigh))*self.n_lower**2 + torch.maximum(rayleigh - self.n_upper ** 2, torch.zeros_like(rayleigh))*self.n_lower**2 + 1/(rayleigh/a - b)
    #         losses_3 += torch.maximum(n_lower ** 2 - rayleigh, torch.zeros_like(rayleigh))*n_lower**2 + torch.maximum(rayleigh - n_upper ** 2, torch.zeros_like(rayleigh))*n_lower**2 + (n_upper**2 - n_lower**2)/(rayleigh - n_lower**2)

            # losses_3 += torch.maximum(n_lower ** 2 - rayleigh, torch.zeros_like(rayleigh)) + torch.maximum(rayleigh - n_upper ** 2, torch.zeros_like(rayleigh)) - rayleigh/(i+1) + torch.square(rayleigh_diff)
            rayleigh_values.append(torch.sqrt(rayleigh.detach()).item())

            for j in range(i + 1, num_modes):
                losses_4 += torch.abs(cosine_similarity_fn(u[:, i], u[:, j]))

        return losses_1, losses_2, losses_3, losses_4, rayleigh_values


    def construct_training_data(self):
        xy = self.sampler(self.device, self.num_samples if self.num_samples else self.dx,  self.num_samples if self.num_samples else self.dy, self.dtype, self.memory_type)
        xy.requires_grad = True
        if self.device.augmented_input:
            n_squared = self.device.refractive_index(xy, format='torch').detach().reshape(-1, 1) ** 2
            xy = torch.cat((xy, n_squared), dim=1).to(self.memory_type)

        print('num samples', len(xy))
        return xy


    def train(self, epochs, num_modes, weights=[1, 1, 1, 1, 1, 1], verbose=0, calc_error=False, plot_solution=False, sample_new=False):
        if verbose ==10:
            loop = tqdm.tqdm(range(epochs))
        else:
            loop = range(epochs)

        loss_history = []
        rayleigh_history = [[] for _ in range(num_modes)]

        self.device.underlying_model.to(self.memory_type)
        self.device.underlying_model.to(self.dtype)

        xy = self.construct_training_data()
        xy.to(self.memory_type)

        interfaces = self.device.get_discontinuities(xy[:, :2].detach().clone(), self.dx, self.dy)
        for interface in interfaces:
            interface.requires_grad=True

        bd, u_bd = self.device.get_boundaries(xy[:, :2].detach().clone(), self.dx, self.dy, self.dtype,  self.memory_type)
        if self.device.augmented_input:
            n_squared_bd = self.device.refractive_index(bd, format='torch').detach().reshape(-1, 1) ** 2
            bd = torch.cat((bd, n_squared_bd), dim=1)

        mode_errors_list = []
        for i in range(num_modes):
            mode_errors_list.append([])
    
        plt.scatter(bd[:, 0].cpu(), bd[:, 1].cpu(), s=1)
        plt.scatter(interfaces[0][:, 0].cpu().detach(), interfaces[0][:, 1].cpu().detach(), s=1)
        plt.scatter(interfaces[1][:, 0].cpu().detach(), interfaces[1][:, 1].cpu().detach(), s=1)
        plt.show()

        for j in loop:
            def closure():
                self.optimizer.zero_grad()

                u_pred = self.device.underlying_model(xy)
                u_pred_bd = self.device.underlying_model(bd)

                # normalization_const = torch.linalg.norm(u_pred, dim=0, keepdims=True) / 4
                # u_pred = u_pred / normalization_const
                # u_pred_bd = self.device.underlying_model(bd) / normalization_const

                loss_1, loss_2, loss_3, loss_4, rayleigh_values = self.interior_loss(xy, u_pred, num_modes)
                loss_5 = self.bd_loss(u_bd, u_pred_bd)
                loss_6 = self.continuity_loss(interfaces, num_modes)

                (weights[0]*loss_1 + weights[1]*loss_2+ weights[2]*loss_3+ weights[3]*loss_4+ weights[4]*loss_5 +weights[5]*loss_6).backward(retain_graph=True)
                nn.utils.clip_grad_norm_(self.device.underlying_model.parameters(), 1.0)

                loss_history.append((loss_1 + loss_2 + loss_3 + loss_4 + loss_5 + loss_6).detach().item())

                for i in range(num_modes):
                    rayleigh_history[i].append(rayleigh_values[i])

                if verbose == 10:
                    loop.set_description(f'loss1 is {round(loss_1.detach().item(), 5)}, loss2 is {round(loss_2.detach().item(), 5)}, loss3 is {round(loss_3.detach().item(), 5)}, loss4 is {round(loss_4.detach().item(), 5)}, loss5 is {round(loss_5.detach().item(), 5)}, loss6 is {round(loss_6.detach().item(), 5)}')
                elif verbose > 0:
                    if j%(int(1000/verbose))==0:
                      print((f'iteration {j+1} loss1 is {round(loss_1.detach().item(), 5)}, loss2 is {round(loss_2.detach().item(), 5)}, loss3 is {round(loss_3.detach().item(), 5)}, loss4 is {round(loss_4.detach().item(), 5)}, loss5 is {round(loss_5.detach().item(), 5)}, loss6 is {round(loss_6.detach().item(), 5)}'))
                
                return (weights[0]*loss_1 + weights[1]*loss_2+ weights[2]*loss_3+ weights[3]*loss_4+ weights[4]*loss_5 +weights[5]*loss_6)

            self.optimizer.step(closure)
            self.scheduler.step()

            if verbose > 0:
                if j%(int(1000/verbose))==0:
                    with torch.no_grad():
                        u = self.device.underlying_model(xy)
                        # normalization_const = torch.linalg.norm(u, dim=0, keepdims=True) / 4
                        # u = u / normalization_const
                    print(rayleigh_history[0][-1])
                    if plot_solution:
                        plt.tricontourf(xy[:, 0].detach().cpu(), xy[:, 1].detach().cpu(),u[:, 0].cpu().view(-1), cmap='jet')
                        plt.colorbar()
                        plt.grid()
                        plt.show()
                        plt.plot(rayleigh_history[0])
                        plt.show()

                    if calc_error:
                        mode_errors = utils.compare_against_analytic(self.device, x_rayleigh[:, [0]].clone().detach().cpu().numpy(), u.cpu())
                        for i in range(num_modes):
                            mode_errors_list[i].append(mode_errors[i])
        if verbose == 10:
          loop.close()

        return loss_history, rayleigh_history, mode_errors_list